<?php
$sql = 'ALTER TABLE app_updates ADD COLUMN upload_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP;';
?>